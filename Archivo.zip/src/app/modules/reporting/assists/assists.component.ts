import { Component, OnInit, ViewEncapsulation } from '@angular/core';

@Component({
  selector: 'app-assists',
  templateUrl: './assists.component.html',
  styleUrls: ['./assists.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class AssistsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
