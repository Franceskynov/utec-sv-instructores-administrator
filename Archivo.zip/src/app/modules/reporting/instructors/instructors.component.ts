import { Component, OnInit, ViewEncapsulation } from '@angular/core';

@Component({
  selector: 'app-instructors',
  templateUrl: './instructors.component.html',
  styleUrls: ['./instructors.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class InstructorsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
