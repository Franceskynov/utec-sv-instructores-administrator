import { Component, OnInit, ViewEncapsulation } from '@angular/core';

@Component({
  selector: 'app-teachers',
  templateUrl: './teachers.component.html',
  styleUrls: ['./teachers.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class TeachersComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
